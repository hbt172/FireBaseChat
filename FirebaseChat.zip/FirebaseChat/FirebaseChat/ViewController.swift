//  ViewController.swift
//  FirebaseChat
//
//  Created by Nirav Joshi on 23/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//
import UIKit
import Firebase
import Reachability
import CoreData
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    @IBOutlet weak var ObjProgressView: UIProgressView!
    @IBOutlet weak var imgView: UIImageView!
    var maincontext = AppDelegate.mainDelegate().persistentContainer.viewContext
    var receiver_id = String()
    var aryMessage = [[String : Any]]()
    @IBOutlet weak var txtMessage: UITextField!
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var tblChat: UITableView!
    let reachability = Reachability()!
    let storage = Storage.storage(url:"gs://fir-chat-ce32e.appspot.com")
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print(receiver_id)
        tblChat.register(UINib.init(nibName: "RightSideTableCell", bundle: Bundle.main), forCellReuseIdentifier: "RightSideTableCell")
        tblChat.register(UINib.init(nibName: "LeftSideTableCell", bundle: Bundle.main), forCellReuseIdentifier: "LeftSideTableCell")
        tblChat.register(UINib.init(nibName: "ImageViewTableCell", bundle: Bundle.main), forCellReuseIdentifier: "ImageViewTableCell")
        
        GetAllData()
        //declare this inside of viewWillAppear
        NotificationCenter.default.addObserver(self, selector: #selector(reachabilityChanged(note:)), name: .reachabilityChanged, object: reachability)
        do
        {
            try reachability.startNotifier()
        }
        catch
        {
            print("could not start reachability notifier")
        }
        FetchCoredataMessage()
        tblChat.rowHeight = 44.0
        tblChat.estimatedRowHeight = UITableView.automaticDimension
    }
    
    
    @objc func reachabilityChanged(note: Notification)
    {
        let reachability = note.object as! Reachability
        switch reachability.connection {
        case .wifi:
            print("Reachable via WiFi")
        case .cellular:
            print("Reachable via Cellular")
        case .none:
            print("Network not reachable")
        }
    }
    
    @IBAction func btnSendClick(_ sender: Any)
    {
        if reachability.connection == .none
        {
            let alrt = UIAlertController(title: "error", message: "network connection off", preferredStyle: .alert)
            let  alrtAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil)
            alrt.addAction(alrtAction)
            self.present(alrt, animated: true, completion: nil)
            
            let message = Messages(entity: NSEntityDescription.entity(forEntityName: "Messages", in: maincontext)!, insertInto: maincontext)
            message.receiver_ID = 2
            message.sender_ID = 1
            message.text = txtMessage.text
            message.timestamp = NSDate().timeIntervalSince1970
            do{
                try  maincontext.save()
            } catch let error as NSError {
                print("Could not save. \(error), \(error._userInfo!)")
            }
            let dicMessage = ["sender_id": 2,"receiver_id" : 1, "text": txtMessage.text as Any,"timestamp": NSDate().timeIntervalSince1970,"ImageURL" : ""] as [String : Any]
            aryMessage.append(dicMessage)
        }
        else
        {
                let ref = Constants.refs.databaseMessages.childByAutoId()
            let message = ["sender_id": 2,"receiver_id" : 1, "text": txtMessage.text as Any,"timestamp": NSDate().timeIntervalSince1970,"ImageURL" : ""] as [String : Any]
            ref.setValue(message)
//            aryMessage.append(message)
//            tblChat.reloadData()
            let indexPath = IndexPath(row: self.aryMessage.count-1, section: 0)
//            self.tblChat.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: false)
            tblChat.reloadRows(at: [indexPath], with: UITableView.RowAnimation.bottom)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func GetAllData()
    {
        Constants.refs.databaseMessages.observe(.value, with: { (snap : DataSnapshot) in
//        Constants.refs.databaseMessages.observeSingleEvent(of: .value, with: { (snap : DataSnapshot)  in
            //            if let snapDict = snap.value! as? [String : AnyObject]{
            //                print(snapDict.keys)   //Retrieving My AutoID .Nut this gives me entire node.
            //            }
            //            print("\(String(describing:  snap.value))")
            if snap.exists(){
                for each in snap.value as! [String:AnyObject]{
                    print(each.key)
                    //                    Constants.refs.databaseChats.child(each.key).observeSingleEvent(of: .value, with: {(IMsnap) in
                    //                         print(IMsnap)
                    //                        if IMsnap.exists(){
                    //                            print("\(String(describing:  IMsnap.value))")
                    //                            self.aryMessage.append(IMsnap.value as! [String : Any])
                    //                            self.aryMessage.sort(by: { (element1, element2) -> Bool in
                    //                                return (element1["text"] as! String) < (element2["text"] as! String)
                    //                            })
                    //                            self.tblChat.reloadData()
                    //                        }
                    //                    })
                    let childSnapshot1 = snap.childSnapshot(forPath:each.key)
                    let userDict = childSnapshot1.value as! [String: Any]
                    self.aryMessage.append(userDict)
                    self.aryMessage.sort(by: { (element1, element2) -> Bool in
                        return (element1["timestamp"] as! Double) < (element2["timestamp"] as! Double)
                    })
//                    let indexPath = IndexPath(row: self.aryMessage.count-1, section: 0)
//                    self.tblChat.scrollToRow(at: indexPath, at: UITableView.ScrollPosition.bottom, animated: true)
                }
                self.tblChat.reloadData()
            }
            else
            {
            }
        }) { (err: Error) in
            print("\(err.localizedDescription)")
            
        }
    }
    // MARK:- Tableview delegate and datasource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryMessage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let image: UIImage? = ((aryMessage[indexPath.row] as [String:Any])["ImageView"] as? UIImage)
        if image != nil {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ImageViewTableCell", for: indexPath) as! ImageViewTableCell
            cell.imgViewCell.image = ((aryMessage[indexPath.row] as [String:Any])["ImageView"] as! UIImage)
            cell.ProgressView.isHidden = true
            return cell
        }
        else
        {
            if Int(receiver_id) == ((aryMessage[indexPath.row] as [String:Any])["sender_id"] as! Int)
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "RightSideTableCell", for: indexPath) as! RightSideTableCell
                cell.lblMessage.text = ((aryMessage[indexPath.row] as [String : Any])["text"] as! String)
                if (cell.lblMessage.text!.height(withConstrainedWidth: self.view.frame.size.width - 30, font: cell.lblMessage.font)) < 30.0
                {
                    cell.ViewLeadingConstarints.constant = self.view.frame.size.width - (cell.lblMessage.text!.width(withConstrainedHeight: cell.lblMessage.frame.size.height, font: cell.lblMessage.font) + 20.0)
                }
                return cell
            }
            else
            {
                let cell = tableView.dequeueReusableCell(withIdentifier: "LeftSideTableCell", for: indexPath) as! LeftSideTableCell
                cell.lblMessage.text = ((aryMessage[indexPath.row] as [String : Any])["text"] as! String)
                if (cell.lblMessage.text!.height(withConstrainedWidth: self.view.frame.size.width - 30, font: cell.lblMessage.font)) < 30.0
                {
                    cell.ViewTrailingConstraints.constant = self.view.frame.size.width - (cell.lblMessage.text!.width(withConstrainedHeight: cell.lblMessage.frame.size.height, font: cell.lblMessage.font) + 20.0)
                }
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let image: UIImage? = ((aryMessage[indexPath.row] as [String:Any])["ImageView"] as? UIImage)
        if image != nil
        {
            return 100.0
        }
        else
        {
            return UITableView.automaticDimension
        }
    }
    
    @IBAction func btnBackClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    func  FetchCoredataMessage() {
        do
        {
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Messages")
            let fetchedResults = try maincontext.fetch(fetchRequest)
            for i in 0..<fetchedResults.count
            {
                //                let single_result = fetchedResults[i]
                //                let index = (single_result as AnyObject).value(forKey:  "index") as! NSInteger
                //                let img: NSData? = (single_result as AnyObject).value(forKey: "image") as? NSData
                //                TableData[index].image = UIImage(data: img! as Data)
                
                print(fetchedResults[i])
                let strText: NSString? = (fetchedResults[i] as AnyObject).value(forKey: "text") as? NSString
                let dicMessage = ["sender_id": (fetchedResults[i] as AnyObject).value(forKey: "sender_ID") as! Int,"receiver_id" : (fetchedResults[i] as AnyObject).value(forKey: "receiver_ID") as! Int,"text": (fetchedResults[i] as AnyObject).value(forKey: "text") as! NSString,"timestamp": (fetchedResults[i] as AnyObject).value(forKey: "timestamp") as! Double] as [String : Any]
                aryMessage.append(dicMessage)
                maincontext.delete(fetchedResults[i] as! NSManagedObject)
                tblChat.reloadData()
                print("coredata base message \(strText!)")
            }
        }
        catch
        {
            print("error")
        }
    }
    
    @IBAction func btnImageClick(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            let imag = UIImagePickerController()
            imag.delegate = self
            imag.sourceType = UIImagePickerController.SourceType.photoLibrary;
            //imag.mediaTypes = [kUTTypeImage];
            imag.allowsEditing = false
            self.present(imag, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
//        imgView.image = pickedImage
        let storageRef = storage.reference()
        let imageRef = storageRef.child("images/lock.png")
        let uploadTask = imageRef.putData((pickedImage?.pngData())!, metadata: nil, completion: { (metadata,error) in
            guard metadata != nil else{
                print(error as Any)
                return
            }
            imageRef.downloadURL { (url, error) in
                guard let downloadURL = url else {
                    return
                }
                print(downloadURL)
                let ref = Constants.refs.databaseMessages.childByAutoId()
                let message = ["sender_id": 2,"receiver_id" : 1, "text": self.txtMessage.text as Any,"timestamp": NSDate().timeIntervalSince1970,"ImageURL" : String(describing: downloadURL)] as [String : Any]
                ref.setValue(message)
                let storageRef = Storage.storage().reference(forURL: String(describing: downloadURL))
                storageRef.downloadURL(completion: { (url, error) in
                    do {
                        let data = try Data(contentsOf: url!)
                        let image = UIImage(data: data as Data)
                        self.imgView.image = image
                    } catch  {
                    }
                })
            }
        })
        
        uploadTask.observe(.progress, handler: { (snapshot) in
            guard let progress = snapshot.progress else {
                return
            }
            let percentage = (Double(progress.completedUnitCount) / Double(progress.totalUnitCount)) * 100
            print(percentage)
            self.ObjProgressView.progress = Float((snapshot.progress?.fractionCompleted)!)
            //            progressBlock(percentage)
        })
        let message = ["ImageView": pickedImage as Any] as [String : Any]
        self.aryMessage.append(message)
        self.tblChat.reloadData()
        self.dismiss(animated: true, completion: nil)
    }
}
