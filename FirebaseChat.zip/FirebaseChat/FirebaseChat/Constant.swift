//
//  Constant.swift
//  FirebaseChat
//
//  Created by Nirav Joshi on 23/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import Foundation
import Firebase
import FirebaseDatabase

struct Constants
{
    struct refs
    {
        static let databaseRoot = FirebaseDatabase.Database.database().reference()
        static let databaseChats = databaseRoot.child("chats")
        static let databaseUsers = databaseRoot.child("users")
        static let databaseMessages = databaseRoot.child("messages")
    }
}
