//
//  UserVC.swift
//  FirebaseChat
//
//  Created by Nirav Joshi on 23/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import FirebaseAuth
class UserVC: UIViewController {
    
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPhoneNumber: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtUserID: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func btnSaveClick(_ sender: Any) {
        let ref = Constants.refs.databaseUsers.child(txtUserID.text!)
        let message = ["UserID" : txtUserID.text, "UserName" : txtUserName.text, "Email" : txtEmail.text, "PhoneNumber" : txtPhoneNumber.text]
        ref.setValue(message)
    }
    
    @IBAction func btnCreateUserClick(_ sender: Any) {
        Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
            if error != nil
            {
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                self.present(alertController, animated: true, completion: nil)
            }
            else
            {
                print(user?.user.email! as Any)
            }
        }
    }
    @IBAction func btnLoginClick(_ sender: Any) {
        //        Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
        //            if error != nil
        //            {
        //
        //            }
        //            else{
        //                print(user as Any)
        //            }
        //        }
        
        Auth.auth().signIn(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
            
            if let user = user {
                
                let uid = user.user.uid
                let email = user.user.email
                let photoURL = user.user.photoURL
                // ...
                print("\(uid) \(email ?? "")")
            }
            
            if error != nil
            {
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                self.present(alertController, animated: true, completion: nil)
            }
            else{
                print(user?.user.email! as Any)
            }
        }
        
    }
    @IBAction func btnChatClick(_ sender: Any) {
        Constants.refs.databaseUsers.observeSingleEvent(of: .value, with: { (DataSnapshot) in
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatListVC") as! ChatListVC
            vc.objDataSnapshot = DataSnapshot
            self.navigationController?.pushViewController(vc, animated: true)
            //            print("\(DataSnapshot.children.allObjects)")
            //
            //            if let snapDict = DataSnapshot.value as? [String : Any]{
            //
            //                print("\(String(describing: snapDict.keys))")
            //            }
            //            for item in DataSnapshot.children.allObjects
            //            {
            //                print((item as AnyObject).key as Any)
            //            }
        }) { (error : Error) in
        }
    }
}
