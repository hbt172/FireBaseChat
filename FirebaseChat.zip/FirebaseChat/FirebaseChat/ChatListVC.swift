//
//  ChatListVC.swift
//  FirebaseChat
//
//  Created by Nirav Joshi on 24/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ChatListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    var objDataSnapshot = DataSnapshot()
    var aryUser = [[String:Any]]()
    @IBOutlet weak var tblChatLList: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        for child in objDataSnapshot.children
        {
            let childSnapshot1 = objDataSnapshot.childSnapshot(forPath: (child as AnyObject).key)
           let userDict = childSnapshot1.value as! [String: Any]
            print("\(userDict["UserName"]! as Any)")
            aryUser.append(userDict)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserListCell", for: indexPath) as UITableViewCell
        cell.textLabel?.text = (aryUser[indexPath.row]["UserName"] as! String)
        return cell
    }
  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        vc.receiver_id = (aryUser[indexPath.row]["UserID"] as! String)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
