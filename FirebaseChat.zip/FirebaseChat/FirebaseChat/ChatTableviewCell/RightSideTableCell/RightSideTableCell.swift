//
//  RightSideTableCell.swift
//  FirebaseChat
//
//  Created by Nirav Joshi on 23/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class RightSideTableCell: UITableViewCell {

    @IBOutlet weak var ViewLeadingConstarints: NSLayoutConstraint!
    @IBOutlet weak var lblMessage: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
