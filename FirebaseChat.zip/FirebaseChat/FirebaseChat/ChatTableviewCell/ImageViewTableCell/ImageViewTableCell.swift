//
//  ImageViewTableCell.swift
//  FirebaseChat
//
//  Created by Hardik on 01/11/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ImageViewTableCell: UITableViewCell {
    @IBOutlet weak var ProgressView: CircularProgressBar!
    @IBOutlet weak var imgViewCell: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
